import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SalesreportComponent } from './sales/salesreport.component';
import { ProductsListComponent } from './product/products-list.component';
import { ConverttospacePipe } from './shared/converttospace.pipe';
import { StarComponent } from './shared/star.component';
import {HttpClientModule} from '@angular/common/http';
import { ProductService } from './services/product.service';
import { WelcomeComponent } from './welcome/welcome.component';
import { RouterModule } from '@angular/router';
import { ProductDetailComponent } from './product/productDetails/product-detail.component';
import { DeleteProductComponent } from './product/deleteProduct/delete-product.component';
import { AddProductComponent } from './product/addProduct/add-product.component';


@NgModule({
  declarations: [
    AppComponent,
    SalesreportComponent,
    ProductsListComponent,
    ConverttospacePipe,
    StarComponent,
    WelcomeComponent,
    ProductDetailComponent,
    DeleteProductComponent,
    AddProductComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: 'products', component: ProductsListComponent },
      { path: 'welcome', component: WelcomeComponent },
      {path: 'product/:id', component: ProductDetailComponent},
      {path: 'deleteProduct/:id', component: DeleteProductComponent},
      {path: 'addProduct', component:AddProductComponent},
      { path: '', redirectTo: 'welcome', pathMatch: 'full'}

    ]),

  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
