import { ConverttospacePipe } from './converttospace.pipe';

describe('ConverttospacePipe', () => {
  it('create an instance', () => {
    const pipe = new ConverttospacePipe();
    expect(pipe).toBeTruthy();
  });
});
