import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/products/product';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  pageTitle: string = 'Product Detail';
  errorMessage: string;
  product: Product;

  constructor(private route:ActivatedRoute, private router:Router, private productService: ProductService) { }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    const productId = +id;
    this.productService.getProductDetails(productId).subscribe(
      product=>{
        this.product=product;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      });
  }

  public navigateBack(): void{
    this.router.navigate(['/products']);
  }

}
