import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';
import { Product } from 'src/app/products/product';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})

export class AddProductComponent implements OnInit {

  product: Product = {productId: 0, productName : '', productCode : '', releaseDate : '', price : 0, description : '', starRating : 0};
 
  pageTitle: string = 'Add Product Details'
  
  productId : number;
  productName : string;
  productCode : string;
  releaseDate : string;
  price : number;
  description : string;
  starRating : number;
 
  error: string;
  message:string;

  get _productId():number {
    return this.product.productId;
  }
  set _productId(value:number) {
  this.product.productId = value;
  }

  get _productName():string {
    return this.product.productName;
  }
  set _productName(value:string) {
  this.product.productName = value;
  }

  get _productCode():string {
    return this.product.productCode;
  }
  set _productCode(value:string) {
  this.product.productCode = value;
  }

  get _releaseDate():string {
    return this.product.releaseDate;
  }
  set _releaseDate(value:string) {
  this.product.releaseDate = value;
  }

  get _description():string {
    return this.product.description;
  }
  set _description(value:string) {
  this.product.description = value;
  }

  get _starRating():number {
    return this.product.starRating;
  }
  set _starRating(value:number) {
  this.product.starRating = value;
  }
  
  constructor(private route:ActivatedRoute, private router: Router, private productService: ProductService) { }

  ngOnInit() {
    
  }
  addproduct(){
    this.productService.addProductDetails(this.product).subscribe(
      message=>{
        this.message=message;
      },
      error=>{
        this.error=error;
      }
    );
    
  }
  
  public navigateBack(){
    this.router.navigate(['/products']);
  }

}
