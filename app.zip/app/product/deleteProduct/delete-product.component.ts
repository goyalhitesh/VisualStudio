import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';
import { Product } from 'src/app/products/product';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-delete-product',
  templateUrl: './delete-product.component.html',
  styleUrls: ['./delete-product.component.css']
})
export class DeleteProductComponent implements OnInit {
  pageTitle:string='Delete Product Details';
  error:string;
  product:Product;
  message:string = 'Product has successfully deleted.';

  constructor(private route:ActivatedRoute,private router:Router,private productService:ProductService) { }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    const productId = +id;
    
    this.productService.getProductDetails(productId).subscribe(
      product=>{
        this.product=product;
      },
      errorMessage=>{
        this.error=errorMessage;
      });

  }

  deleteProductDetail(){
    const id = this.route.snapshot.paramMap.get('id');
    const productId = +id;
    this.productService.deleteProductDetails(productId).subscribe(
      message=>{
        this.message=message;
      },
      errorMessage=>{
        this.error=errorMessage;
        this.router.navigate(['/products']);
      });
  }

  public navigateBack(): void{
    this.router.navigate(['/products']);
  }
}
